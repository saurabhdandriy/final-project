package com.uas.bean;


/*package com.vaannila.student;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "STUDENT")
public class Student {

	private long studentId;
	private String studentName;
	private Address studentAddress;

	public Student() {
	}

	public Student(String studentName, Address studentAddress) {
		this.studentName = studentName;
		this.studentAddress = studentAddress;
	}

	@Id
	@GeneratedValue
	@Column(name = "STUDENT_ID")
	public long getStudentId() {
		return this.studentId;
	}

	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}

	@Column(name = "STUDENT_NAME", nullable = false, length = 100)
	public String getStudentName() {
		return this.studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	@OneToOne(cascade = CascadeType.ALL)
	public Address getStudentAddress() {
		return this.studentAddress;
	}

	public void setStudentAddress(Address studentAddress) {
		this.studentAddress = studentAddress;
	}

}
*/

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.NamedQuery;
import org.springframework.format.annotation.DateTimeFormat;


@Entity
	@NamedQuery(name="getAllSchedule",query="select sb from ScheduleBean sb")
@Table(name="Programs_Scheduled")
public class ScheduleBean {
	
	@Id
	@GeneratedValue
	@Column(name="Schedule_Program_Id ")
	private int scheduleProgramId;
	
	@Column(name="Program_Name")
	private String programName;
	
	@Column(name="Location ")
	private String location;
	
	
	
	@Column(name="StartDate ")
	private String startDate;
	
	
	
	@Column(name="EndDate ")
	private String endDate;
	@Column(name="Sessions_Per_Week")
	private int  SessionsPerWeek;
	
	public int getSessionsPerWeek() {
		return SessionsPerWeek;
	}
	public void setSessionsPerWeek(int sessionsPerWeek) {
		this.SessionsPerWeek = sessionsPerWeek;
	}
	public ScheduleBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ScheduleBean(int scheduleProgramId, String programName,
			String location, String startDate, String endDate,
			int sessionsPerWeek) {
		super();
		this.scheduleProgramId = scheduleProgramId;
		this.programName = programName;
		this.location = location;
		this.startDate = startDate;
		this.endDate = endDate;
		this.SessionsPerWeek = sessionsPerWeek;
	}
	public int getScheduleProgramId() {
		return scheduleProgramId;
	}
	public void setScheduleProgramId(int scheduleProgramId) {
		this.scheduleProgramId = scheduleProgramId;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	@Override
	public String toString() {
		return "ScheduleProgramId  =  " + scheduleProgramId
				+ ", ProgramName  =  " + programName + ", Location  =  " + location
				+ ", StartDate  =  " + startDate + ", EndDate  =  " + endDate
				+ ", SessionsPerWeek  =  " + SessionsPerWeek;
	}
	
}
